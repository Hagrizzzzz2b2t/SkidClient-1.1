You are free to clone, modify SkidClient and make pull requests.
