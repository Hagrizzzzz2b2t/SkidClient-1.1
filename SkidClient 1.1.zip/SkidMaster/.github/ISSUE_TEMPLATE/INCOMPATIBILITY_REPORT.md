---
name: Incompatibility Report
about: Module incompatibility or incompatible with another Forge mod
labels: -incompatible
---

**What mod?**
<!-- A clear and concise description of what module it is. -->

**Logs**
<!-- Please add logs or your issue will be closed. -->

**Additional context**
<!-- Add any other context about the problem here. -->
